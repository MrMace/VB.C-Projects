﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Retail_Price_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //CalculateRetail method accepts agrument for price, markUp
        //and returns.
        private double CalculateRetail(double price, double markUp)
        {
            //Return price from calculation.
            return price + ((price * markUp) / 100);
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Variables
                double price;
                double markUp;
                double retail;

                //String to double
                price = double.Parse(costTextBox.Text);
                markUp = double.Parse(markUpTextBox.Text);

                //call Method.
                retail = CalculateRetail(price, markUp);

                //Display 
                MessageBox.Show("The retial price is $" + retail);



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close app
            this.Close();
        }

    }
}
