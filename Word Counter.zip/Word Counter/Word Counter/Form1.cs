﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Counter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Accepts WordsCount method accepts a string argument
        // and returns the number of words it contains.
        private int WordsCount(String str)
        {
            int wordCount = 0; //number of words.
            //Get words from string.
            string[] strWords = str.Split(null);
            //Counts words in string.
            wordCount = strWords.Length;
            //return value
            return wordCount;
        }
        private void countButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Adds words to count to string.
                string str = phraseTextBox.Text;

                int numWords = WordsCount(str);
                //Displays the total amount of words.
                MessageBox.Show("The total number of words are : " + numWords.ToString());
            }
            catch (Exception ex)
            {
                //Display error message
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
