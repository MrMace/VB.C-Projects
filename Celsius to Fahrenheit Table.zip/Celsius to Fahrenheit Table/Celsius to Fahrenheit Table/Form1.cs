﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Celsius_to_Fahrenheit_Table
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {

            //Constants
            const int START_TEMP = 0;
            const int END_TEMP = 20;
            const int INTERVAL = 1;
            const double CONVERSION_FACTOR = 1.8;
            const double CONVERSION_FACTOR2 = 32;

            double fahrenheit; //Hold fahrenheit variable.
            double celsius; // Hold celsius variable.

            //Display the table for tempeture
            for (celsius = START_TEMP; celsius <= END_TEMP; celsius += INTERVAL )
            {
                //Calculate farenheit.
                fahrenheit = CONVERSION_FACTOR * celsius + CONVERSION_FACTOR2;

                //Display the converstion
                outputListBox.Items.Add(celsius + " celsius is the same as " + 
                    fahrenheit + " fahrenheit.");
                   
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
