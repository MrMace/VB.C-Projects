﻿namespace Paint_Job_Estimator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sqFootLabel = new System.Windows.Forms.Label();
            this.sqFootTextBox = new System.Windows.Forms.TextBox();
            this.priceOfPaintLabel = new System.Windows.Forms.Label();
            this.priceForPainTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.numGallonsPaintLabel = new System.Windows.Forms.Label();
            this.gallonsNeedTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numHourLaborTextBox = new System.Windows.Forms.TextBox();
            this.costOfPaintLabel = new System.Windows.Forms.Label();
            this.paintCostTextBox = new System.Windows.Forms.TextBox();
            this.laborChargeLabel = new System.Windows.Forms.Label();
            this.laborChargesTextBox = new System.Windows.Forms.TextBox();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.totalCostTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // sqFootLabel
            // 
            this.sqFootLabel.AutoSize = true;
            this.sqFootLabel.Location = new System.Drawing.Point(6, 44);
            this.sqFootLabel.Name = "sqFootLabel";
            this.sqFootLabel.Size = new System.Drawing.Size(168, 17);
            this.sqFootLabel.TabIndex = 0;
            this.sqFootLabel.Text = "Enter the sq foot amount:";
            this.sqFootLabel.Click += new System.EventHandler(this.sqFootLabel_Click);
            // 
            // sqFootTextBox
            // 
            this.sqFootTextBox.Location = new System.Drawing.Point(293, 39);
            this.sqFootTextBox.Name = "sqFootTextBox";
            this.sqFootTextBox.Size = new System.Drawing.Size(100, 22);
            this.sqFootTextBox.TabIndex = 2;
            // 
            // priceOfPaintLabel
            // 
            this.priceOfPaintLabel.AutoSize = true;
            this.priceOfPaintLabel.Location = new System.Drawing.Point(6, 87);
            this.priceOfPaintLabel.Name = "priceOfPaintLabel";
            this.priceOfPaintLabel.Size = new System.Drawing.Size(247, 17);
            this.priceOfPaintLabel.TabIndex = 3;
            this.priceOfPaintLabel.Text = "Enter the price of the paint per gallon:";
            // 
            // priceForPainTextBox
            // 
            this.priceForPainTextBox.Location = new System.Drawing.Point(293, 82);
            this.priceForPainTextBox.Name = "priceForPainTextBox";
            this.priceForPainTextBox.Size = new System.Drawing.Size(100, 22);
            this.priceForPainTextBox.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.calculateButton);
            this.groupBox1.Controls.Add(this.priceOfPaintLabel);
            this.groupBox1.Controls.Add(this.priceForPainTextBox);
            this.groupBox1.Controls.Add(this.sqFootLabel);
            this.groupBox1.Controls.Add(this.sqFootTextBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(416, 262);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter information here";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.totalCostTextBox);
            this.groupBox2.Controls.Add(this.totalCostLabel);
            this.groupBox2.Controls.Add(this.laborChargesTextBox);
            this.groupBox2.Controls.Add(this.laborChargeLabel);
            this.groupBox2.Controls.Add(this.paintCostTextBox);
            this.groupBox2.Controls.Add(this.costOfPaintLabel);
            this.groupBox2.Controls.Add(this.numHourLaborTextBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.gallonsNeedTextBox);
            this.groupBox2.Controls.Add(this.numGallonsPaintLabel);
            this.groupBox2.Location = new System.Drawing.Point(434, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(347, 303);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Results";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(142, 147);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(111, 33);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(59, 297);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(111, 32);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(283, 297);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(111, 32);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // numGallonsPaintLabel
            // 
            this.numGallonsPaintLabel.AutoSize = true;
            this.numGallonsPaintLabel.Location = new System.Drawing.Point(7, 44);
            this.numGallonsPaintLabel.Name = "numGallonsPaintLabel";
            this.numGallonsPaintLabel.Size = new System.Drawing.Size(179, 17);
            this.numGallonsPaintLabel.TabIndex = 0;
            this.numGallonsPaintLabel.Text = "Number of gallons needed:";
            // 
            // gallonsNeedTextBox
            // 
            this.gallonsNeedTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsNeedTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gallonsNeedTextBox.Location = new System.Drawing.Point(247, 44);
            this.gallonsNeedTextBox.Name = "gallonsNeedTextBox";
            this.gallonsNeedTextBox.Size = new System.Drawing.Size(100, 22);
            this.gallonsNeedTextBox.TabIndex = 1;
            this.gallonsNeedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Number of hours of labor needed:";
            // 
            // numHourLaborTextBox
            // 
            this.numHourLaborTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numHourLaborTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numHourLaborTextBox.Location = new System.Drawing.Point(247, 82);
            this.numHourLaborTextBox.Name = "numHourLaborTextBox";
            this.numHourLaborTextBox.Size = new System.Drawing.Size(100, 22);
            this.numHourLaborTextBox.TabIndex = 3;
            this.numHourLaborTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // costOfPaintLabel
            // 
            this.costOfPaintLabel.AutoSize = true;
            this.costOfPaintLabel.Location = new System.Drawing.Point(7, 122);
            this.costOfPaintLabel.Name = "costOfPaintLabel";
            this.costOfPaintLabel.Size = new System.Drawing.Size(91, 17);
            this.costOfPaintLabel.TabIndex = 4;
            this.costOfPaintLabel.Text = "Cost of paint:";
            // 
            // paintCostTextBox
            // 
            this.paintCostTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintCostTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paintCostTextBox.Location = new System.Drawing.Point(247, 122);
            this.paintCostTextBox.Name = "paintCostTextBox";
            this.paintCostTextBox.Size = new System.Drawing.Size(100, 22);
            this.paintCostTextBox.TabIndex = 5;
            this.paintCostTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // laborChargeLabel
            // 
            this.laborChargeLabel.AutoSize = true;
            this.laborChargeLabel.Location = new System.Drawing.Point(7, 155);
            this.laborChargeLabel.Name = "laborChargeLabel";
            this.laborChargeLabel.Size = new System.Drawing.Size(92, 17);
            this.laborChargeLabel.TabIndex = 6;
            this.laborChargeLabel.Text = "Cost of labor:";
            // 
            // laborChargesTextBox
            // 
            this.laborChargesTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborChargesTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laborChargesTextBox.Location = new System.Drawing.Point(247, 155);
            this.laborChargesTextBox.Name = "laborChargesTextBox";
            this.laborChargesTextBox.Size = new System.Drawing.Size(100, 22);
            this.laborChargesTextBox.TabIndex = 7;
            this.laborChargesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Location = new System.Drawing.Point(129, 216);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(119, 17);
            this.totalCostLabel.TabIndex = 8;
            this.totalCostLabel.Text = "Total Cost of Job:";
            // 
            // totalCostTextBox
            // 
            this.totalCostTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCostTextBox.Location = new System.Drawing.Point(120, 240);
            this.totalCostTextBox.Name = "totalCostTextBox";
            this.totalCostTextBox.Size = new System.Drawing.Size(137, 24);
            this.totalCostTextBox.TabIndex = 9;
            this.totalCostTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(793, 347);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Paint Job Estimator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label sqFootLabel;
        private System.Windows.Forms.TextBox sqFootTextBox;
        private System.Windows.Forms.Label priceOfPaintLabel;
        private System.Windows.Forms.TextBox priceForPainTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox totalCostTextBox;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.TextBox laborChargesTextBox;
        private System.Windows.Forms.Label laborChargeLabel;
        private System.Windows.Forms.TextBox paintCostTextBox;
        private System.Windows.Forms.Label costOfPaintLabel;
        private System.Windows.Forms.TextBox numHourLaborTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox gallonsNeedTextBox;
        private System.Windows.Forms.Label numGallonsPaintLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

