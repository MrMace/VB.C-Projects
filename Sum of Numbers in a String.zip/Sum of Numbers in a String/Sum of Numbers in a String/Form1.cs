﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sum_of_Numbers_in_a_String
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Get user input
            string str = numbersTextBox.Text.Trim();

            int sum = 0; //hold the sum amount.
            //Create delimiter array
            char[] delim = { ',' };
            //Tokenize the user's input
            string[] tokens = str.Split(delim);
            //calculate the total of numbers
            foreach (string s in tokens)
            {
                sum += int.Parse(s);
            }
                //Display the total.
                MessageBox.Show("The sum of the numbers is: "
                    + sum);
            }
        

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
