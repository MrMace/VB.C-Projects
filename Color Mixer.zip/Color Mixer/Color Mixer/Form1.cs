﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Color_Mixer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mixButton_Click(object sender, EventArgs e)
        {
            if (yellowRadioButton.Checked && yellowRadioButton2.Checked)
                {
                    this.BackColor = Color.Yellow;
                }
            else if (yellowRadioButton.Checked && redRadioButton2.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (yellowRadioButton.Checked && blueRadioButton2.Checked)
            {
                this.BackColor = Color.Green;
            }
            else if (redRadioButton.Checked && redRadioButton2.Checked)
            {
                this.BackColor = Color.Red;
            }
            else if (redRadioButton.Checked && blueRadioButton2.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (redRadioButton.Checked && yellowRadioButton2.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (blueRadioButton.Checked && redRadioButton2.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (blueRadioButton.Checked && blueRadioButton2.Checked)
            {
                this.BackColor = Color.Blue;
            }
            else if (blueRadioButton.Checked && yellowRadioButton2.Checked)
            {
                this.BackColor = Color.Green;
            }
            else
            {
                //If nothing is selected Display message.
                MessageBox.Show("Please select colors to mix");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application.
            this.Close();
        }
       

       
    }
}
