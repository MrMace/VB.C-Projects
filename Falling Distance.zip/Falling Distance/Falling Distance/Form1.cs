﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //The FallingDistance accepts argument and returns value.
       private double FallingDistance(double time)
        {
           //equation computed and returned.
            return 0.5 * 9.8 * Math.Pow(time,2);
        }

       private void calculateButton_Click(object sender, EventArgs e)
       {
           //variables
           double time;
           double distance;
           //gives time variable value
           time = double.Parse(timeTextBox.Text);

           //string to double
           distance = FallingDistance(time);

           //Display
           MessageBox.Show("Object fall distance was " + distance + " meters");
           
       }

       private void exitButton_Click(object sender, EventArgs e)
       {
           //Close application
           this.Close();
       }

    }
}
