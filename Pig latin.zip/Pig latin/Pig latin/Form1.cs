﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pig_latin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string ConvertToPigLatin(string englishWords)
        {
            //declare variables.
            string pigLatin = string.Empty;
            string fLetter = string.Empty;
            string xLetter = string.Empty;

            //position.
            int position = 0;

            //split string delim by space
            string[] englishWord = englishWords.Split();
            foreach (string word in englishWord)
            {
               if (position !=0)
               {
                   pigLatin = pigLatin + " ";
               }
               else
               {
                   position = 1;
               }
                //get first letter of a word.\
               fLetter = word.Substring(0, 1);
                //get remaining letters.
               xLetter = word.Substring(1, word.Length - 1); 
                //translate the english word to pig latin.
               pigLatin = pigLatin + xLetter + fLetter + "AY";

            }
            //return value 
            return pigLatin.ToString();
        }
        private void convertButton_Click(object sender, EventArgs e)
        {
            //use ConvertPigLatin method to convert english to pig latin.
            string pigLatinWord = ConvertToPigLatin(phraseTextBox.Text);
            //Display messagebox the english to pig latin.
            MessageBox.Show(pigLatinWord);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closer application
            this.Close();
        }
    }

}
