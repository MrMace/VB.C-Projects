﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Total_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
              
                //Create array
                decimal[] numbers = new decimal[7];

                int count = 0; //accumulator
                decimal total = 0; //variable
                //StreamReader 
                StreamReader file;

                //Read file.
                file = File.OpenText("Sales.txt"); while (!file.EndOfStream && count < numbers.Length)
                {
                    numbers[count] = decimal.Parse(file.ReadLine());
                    //add to count
                    count++;
                }
                //Close the file.
                file.Close();

                for (int index = 0; index < count; index++)
                {
                    //Add to listBox.
                    salesListBox.Items.Add(numbers[index]);

                    total += numbers[index];
                }
                    //Display total of all sales together.
                    totalSalesTextBox.Text = total.ToString();
                    //Display total number of sales.
                    numSalesTextBox.Text = count.ToString();
            }
            catch (Exception ex)
            {
                //Display error message.
                MessageBox.Show(ex.Message);
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
