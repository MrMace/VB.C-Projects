﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Traveled
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fiveHoursButton_Click(object sender, EventArgs e)
        {
            double speed; // hold speed variable
            double distance; // hold distance variable.

            //get the speed driven.
            speed = double.Parse(mphTextBox.Text);

            // calculate the distance.
            distance = speed * 5;

            // display the distance traveled
            distanceTextBox.Text = distance.ToString();
        }

        private void eightHourButton_Click(object sender, EventArgs e)
        {
            double speed; // hold speed variable
            double distance; // hold distance variable.

            //get the speed driven.
            speed = double.Parse(mphTextBox.Text);

            // calculate the distance.
            distance = speed * 8;

            // display the distance traveled
            distanceTextBox.Text = distance.ToString();
        }

        private void twelveHourButton_Click(object sender, EventArgs e)
        {
            double speed; // hold speed variable
            double distance; // hold distance variable.

            //get the speed driven.
            speed = double.Parse(mphTextBox.Text);

            // calculate the distance.
            distance = speed * 12;

            // display the distance traveled
            distanceTextBox.Text = distance.ToString();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clear textboxes
            mphTextBox.Text = " ";
            distanceTextBox.Text = " ";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close application
            this.Close();
        }
    }
}
