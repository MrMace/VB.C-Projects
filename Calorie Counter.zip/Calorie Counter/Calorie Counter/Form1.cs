﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calorie_Counter
{
    public partial class Form1 : Form
    {
        //Constant fields
        const double ONE_FIFTEEN_CALORIES_VALUE = 115;
        const double EIGHTY_CALORIES_VALUE = 80;
        const double NINTY_CALORIES_VALUE = 90;
        const double ONE_TWENTY_CALORIES_VALUE = 120;

        // field vari hold total
        private double total = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void oneFifteenCalPictureBox_Click(object sender, EventArgs e)
        {
            //Add the 115 calories to the total.
            total += ONE_FIFTEEN_CALORIES_VALUE;

            //Display the total
            calorieCountTextBox.Text = total.ToString();

        }

        private void eightyCalPictureBox_Click(object sender, EventArgs e)
        {
            //Add the 80 calories to the total.
            total += EIGHTY_CALORIES_VALUE;

            //Display the total
            calorieCountTextBox.Text = total.ToString();
        }

        private void nintyCalPictureBox_Click(object sender, EventArgs e)
        {
            //Add the 90 calories to the total.
            total += NINTY_CALORIES_VALUE;

            //Display the total
            calorieCountTextBox.Text = total.ToString();
        }

        private void oneTwentyCalPictureBox_Click(object sender, EventArgs e)
        {
            //Add the 120 calories to the total.
            total += ONE_TWENTY_CALORIES_VALUE;

            //Display the total
            calorieCountTextBox.Text = total.ToString();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            //reset total, and empty text box
            calorieCountTextBox.Text = "0";
            total = 0;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close application
            this.Close();
        }
    }
}
