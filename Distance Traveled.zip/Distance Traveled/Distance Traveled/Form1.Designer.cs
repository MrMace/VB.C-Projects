﻿namespace Distance_Traveled
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mphLabel = new System.Windows.Forms.Label();
            this.mphTextBox = new System.Windows.Forms.TextBox();
            this.fiveHoursButton = new System.Windows.Forms.Button();
            this.eightHourButton = new System.Windows.Forms.Button();
            this.twelveHourButton = new System.Windows.Forms.Button();
            this.distanceLabel = new System.Windows.Forms.Label();
            this.distanceTextBox = new System.Windows.Forms.TextBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mphLabel
            // 
            this.mphLabel.AutoSize = true;
            this.mphLabel.Location = new System.Drawing.Point(12, 42);
            this.mphLabel.Name = "mphLabel";
            this.mphLabel.Size = new System.Drawing.Size(132, 17);
            this.mphLabel.TabIndex = 0;
            this.mphLabel.Text = "Enter vehicles Mph:";
            // 
            // mphTextBox
            // 
            this.mphTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mphTextBox.Location = new System.Drawing.Point(151, 42);
            this.mphTextBox.Name = "mphTextBox";
            this.mphTextBox.Size = new System.Drawing.Size(100, 22);
            this.mphTextBox.TabIndex = 1;
            // 
            // fiveHoursButton
            // 
            this.fiveHoursButton.Location = new System.Drawing.Point(32, 70);
            this.fiveHoursButton.Name = "fiveHoursButton";
            this.fiveHoursButton.Size = new System.Drawing.Size(284, 23);
            this.fiveHoursButton.TabIndex = 2;
            this.fiveHoursButton.Text = "Distance vehicle will travel in 5 hours";
            this.fiveHoursButton.UseVisualStyleBackColor = true;
            this.fiveHoursButton.Click += new System.EventHandler(this.fiveHoursButton_Click);
            // 
            // eightHourButton
            // 
            this.eightHourButton.Location = new System.Drawing.Point(32, 99);
            this.eightHourButton.Name = "eightHourButton";
            this.eightHourButton.Size = new System.Drawing.Size(284, 23);
            this.eightHourButton.TabIndex = 2;
            this.eightHourButton.Text = "Distance vehicle will travel in 8 hours";
            this.eightHourButton.UseVisualStyleBackColor = true;
            this.eightHourButton.Click += new System.EventHandler(this.eightHourButton_Click);
            // 
            // twelveHourButton
            // 
            this.twelveHourButton.Location = new System.Drawing.Point(32, 128);
            this.twelveHourButton.Name = "twelveHourButton";
            this.twelveHourButton.Size = new System.Drawing.Size(284, 23);
            this.twelveHourButton.TabIndex = 2;
            this.twelveHourButton.Text = "Distance vehicle will travel in 12 hours";
            this.twelveHourButton.UseVisualStyleBackColor = true;
            this.twelveHourButton.Click += new System.EventHandler(this.twelveHourButton_Click);
            // 
            // distanceLabel
            // 
            this.distanceLabel.AutoSize = true;
            this.distanceLabel.Location = new System.Drawing.Point(12, 168);
            this.distanceLabel.Name = "distanceLabel";
            this.distanceLabel.Size = new System.Drawing.Size(226, 17);
            this.distanceLabel.TabIndex = 3;
            this.distanceLabel.Text = "Total distance that will be traveled:";
            // 
            // distanceTextBox
            // 
            this.distanceTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.distanceTextBox.Location = new System.Drawing.Point(244, 162);
            this.distanceTextBox.Name = "distanceTextBox";
            this.distanceTextBox.Size = new System.Drawing.Size(100, 27);
            this.distanceTextBox.TabIndex = 4;
            this.distanceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(32, 202);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(241, 202);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 249);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.distanceTextBox);
            this.Controls.Add(this.distanceLabel);
            this.Controls.Add(this.twelveHourButton);
            this.Controls.Add(this.eightHourButton);
            this.Controls.Add(this.fiveHoursButton);
            this.Controls.Add(this.mphTextBox);
            this.Controls.Add(this.mphLabel);
            this.Name = "Form1";
            this.Text = "Distance Traveled";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label mphLabel;
        private System.Windows.Forms.TextBox mphTextBox;
        private System.Windows.Forms.Button fiveHoursButton;
        private System.Windows.Forms.Button eightHourButton;
        private System.Windows.Forms.Button twelveHourButton;
        private System.Windows.Forms.Label distanceLabel;
        private System.Windows.Forms.TextBox distanceTextBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

