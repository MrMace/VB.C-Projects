﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint_Job_Estimator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void sqFootLabel_Click(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double sqFootage; // Hold sqFoot
                double priceOfPaint; // Hold price of the paint.
                double gallonsOfPaint; //Hold gallons of paint.
                double HoursOfLabor; //Hold number hours of labor.
                double costOfPaint; //Hold the cost of the paint.
                double laborCharge; //Hold the labor charge.
                double total; //holds the total.

                //get the sqFootage.
                sqFootage = double.Parse(sqFootTextBox.Text);

                // get cost of price of paint.
                priceOfPaint = double.Parse(priceForPainTextBox.Text);

                // calculate  number of gallons of paint used.
                gallonsOfPaint = sqFootage / 115;

                // calculate number of hours of labor.
                HoursOfLabor = gallonsOfPaint * 8;

                // calculate cost of the paint.
                costOfPaint = gallonsOfPaint * priceOfPaint;

                // calculate the labor charge.
                laborCharge = HoursOfLabor * 20;

                // calculate the total.
                total = costOfPaint + laborCharge;

                //Display Number of gallons of paint.
                gallonsNeedTextBox.Text = gallonsOfPaint.ToString("");

                // Display number of hours of labor.
                numHourLaborTextBox.Text = HoursOfLabor.ToString("");

                //Display the cost of paint.
                paintCostTextBox.Text = costOfPaint.ToString("C");

                // Display the cost of labor
                laborChargesTextBox.Text = laborCharge.ToString("C");

                // Display the total Cost.
                totalCostTextBox.Text = total.ToString("C");
            }
            catch (Exception ex)
            {
                // Display the default error message.
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {

            // Clear all text Boxes
            priceForPainTextBox.Text = " ";
            sqFootTextBox.Text = " ";
            gallonsNeedTextBox.Text = " ";
            numHourLaborTextBox.Text = " ";
            paintCostTextBox.Text = " ";
            laborChargesTextBox.Text = " ";
            totalCostTextBox.Text = " ";

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the Program
            this.Close();
        }
    }
}
