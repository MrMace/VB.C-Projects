﻿namespace Sales_Analysis
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.salesListBox = new System.Windows.Forms.ListBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numSalesTextBox = new System.Windows.Forms.TextBox();
            this.highestTextBox = new System.Windows.Forms.TextBox();
            this.lowestTextBox = new System.Windows.Forms.TextBox();
            this.averageTextBox = new System.Windows.Forms.TextBox();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // salesListBox
            // 
            this.salesListBox.FormattingEnabled = true;
            this.salesListBox.ItemHeight = 20;
            this.salesListBox.Location = new System.Drawing.Point(12, 12);
            this.salesListBox.Name = "salesListBox";
            this.salesListBox.Size = new System.Drawing.Size(204, 244);
            this.salesListBox.TabIndex = 0;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(201, 262);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(102, 32);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(327, 262);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(102, 31);
            this.closeButton.TabIndex = 2;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(232, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Number of sales:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(232, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Largest Sale:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(232, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Lowest Sale:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(232, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Average Sale:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(280, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Total of Sales:";
            // 
            // numSalesTextBox
            // 
            this.numSalesTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numSalesTextBox.Location = new System.Drawing.Point(416, 12);
            this.numSalesTextBox.Name = "numSalesTextBox";
            this.numSalesTextBox.ReadOnly = true;
            this.numSalesTextBox.Size = new System.Drawing.Size(100, 26);
            this.numSalesTextBox.TabIndex = 8;
            this.numSalesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // highestTextBox
            // 
            this.highestTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.highestTextBox.Location = new System.Drawing.Point(416, 50);
            this.highestTextBox.Name = "highestTextBox";
            this.highestTextBox.ReadOnly = true;
            this.highestTextBox.Size = new System.Drawing.Size(100, 26);
            this.highestTextBox.TabIndex = 9;
            this.highestTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lowestTextBox
            // 
            this.lowestTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowestTextBox.Location = new System.Drawing.Point(416, 87);
            this.lowestTextBox.Name = "lowestTextBox";
            this.lowestTextBox.ReadOnly = true;
            this.lowestTextBox.Size = new System.Drawing.Size(100, 26);
            this.lowestTextBox.TabIndex = 10;
            this.lowestTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // averageTextBox
            // 
            this.averageTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.averageTextBox.Location = new System.Drawing.Point(416, 128);
            this.averageTextBox.Name = "averageTextBox";
            this.averageTextBox.ReadOnly = true;
            this.averageTextBox.Size = new System.Drawing.Size(100, 26);
            this.averageTextBox.TabIndex = 11;
            this.averageTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalTextBox
            // 
            this.totalTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalTextBox.Location = new System.Drawing.Point(416, 185);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.ReadOnly = true;
            this.totalTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalTextBox.TabIndex = 12;
            this.totalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 318);
            this.Controls.Add(this.totalTextBox);
            this.Controls.Add(this.averageTextBox);
            this.Controls.Add(this.lowestTextBox);
            this.Controls.Add(this.highestTextBox);
            this.Controls.Add(this.numSalesTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.salesListBox);
            this.Name = "Form1";
            this.Text = "Sales Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox salesListBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox numSalesTextBox;
        private System.Windows.Forms.TextBox highestTextBox;
        private System.Windows.Forms.TextBox lowestTextBox;
        private System.Windows.Forms.TextBox averageTextBox;
        private System.Windows.Forms.TextBox totalTextBox;
    }
}

