﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pennies_for_Pay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {


            // Variables
            int days; //holds days variable
            int count; //hold loop counter
            double pay = 0.01; //hold pay amount
            double total = 0.01; //hold total
            //get amount of days.
            days = int.Parse(daysTextBox.Text);
           
            //for day one loop
            for (count = 1; count == 1; count++)
            {
                //Display Message in Textbox for day one
                listBox.Items.Add("The pay for Susan on days " + count + " is "
                    + pay.ToString("c"));
            }
                //Loop for other days
                for (count = 2; count <= days; count++)
                {
                    //get pay for days 2 two+
                    pay = pay * 2;
                    //Display in textbox pay
                    listBox.Items.Add("The pay for Susan on days " + count + " is " +
                        pay.ToString("c"));
                    total += pay  ;
                }

            // Display in total text box the grand total.
                totalTextBox.Text = total.ToString("c"); 
        }
        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
