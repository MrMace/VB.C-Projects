﻿namespace Random_Number_File_Reader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox = new System.Windows.Forms.ListBox();
            this.openButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.totalRanNumTextBox = new System.Windows.Forms.TextBox();
            this.numberSumTextBox = new System.Windows.Forms.TextBox();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 20;
            this.listBox.Location = new System.Drawing.Point(52, 37);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(318, 204);
            this.listBox.TabIndex = 0;
            // 
            // openButton
            // 
            this.openButton.Location = new System.Drawing.Point(91, 350);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(111, 34);
            this.openButton.TabIndex = 1;
            this.openButton.Text = "Open File";
            this.openButton.UseVisualStyleBackColor = true;
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(208, 349);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(111, 35);
            this.closeButton.TabIndex = 2;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Total random numbers:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sum of all random numbers:";
            // 
            // totalRanNumTextBox
            // 
            this.totalRanNumTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalRanNumTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalRanNumTextBox.Location = new System.Drawing.Point(276, 258);
            this.totalRanNumTextBox.Name = "totalRanNumTextBox";
            this.totalRanNumTextBox.ReadOnly = true;
            this.totalRanNumTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalRanNumTextBox.TabIndex = 5;
            this.totalRanNumTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // numberSumTextBox
            // 
            this.numberSumTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberSumTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberSumTextBox.Location = new System.Drawing.Point(276, 285);
            this.numberSumTextBox.Name = "numberSumTextBox";
            this.numberSumTextBox.ReadOnly = true;
            this.numberSumTextBox.Size = new System.Drawing.Size(100, 26);
            this.numberSumTextBox.TabIndex = 6;
            this.numberSumTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 417);
            this.Controls.Add(this.numberSumTextBox);
            this.Controls.Add(this.totalRanNumTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.openButton);
            this.Controls.Add(this.listBox);
            this.Name = "Form1";
            this.Text = "Random Number File Reader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox totalRanNumTextBox;
        private System.Windows.Forms.TextBox numberSumTextBox;
        private System.Windows.Forms.OpenFileDialog openFile;
    }
}

