﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void middleNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleFirstMiddleLastButton_Click(object sender, EventArgs e)
        {
            //Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = preferredTitleTextBox.Text + " " +
                firstNameTextBox.Text + " " +
                middleNameTextBox.Text + " " +
                lastNameTextBox.Text;

            //Display the output string in the label control.
            formattedNameTextBox.Text = output;
        }

        private void firstMiddleLastNameButton_Click(object sender, EventArgs e)
        {
            //Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output =  firstNameTextBox.Text + " " +
                middleNameTextBox.Text + " " +
                lastNameTextBox.Text;

            //Display the output string in the label control.
            formattedNameTextBox.Text = output;
        }

        private void firstLastNameButton_Click(object sender, EventArgs e)
        {
            //Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = firstNameTextBox.Text + " " +
                lastNameTextBox.Text;

            //Display the output string in the label control.
            formattedNameTextBox.Text = output;
        }

        private void lastFirstMiddleTitleNameButton_Click(object sender, EventArgs e)
        {
            //Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = lastNameTextBox.Text + ", " +
                firstNameTextBox.Text + " " +
                middleNameTextBox.Text + " " +
                preferredTitleTextBox.Text;

            //Display the output string in the label control.
            formattedNameTextBox.Text = output;
        }

        private void lastFirstMiddleNameButton_Click(object sender, EventArgs e)
        {
            //Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = lastNameTextBox.Text + ", " +
                firstNameTextBox.Text + " " +
                middleNameTextBox.Text;

                //Display the output string in the label control.
            formattedNameTextBox.Text = output;
        }

        private void lastFirstNameButton_Click(object sender, EventArgs e)
        {
            //Declare a string variable.
            string output;

            // Concatenate the input and build the output string.
            output = lastNameTextBox.Text + ", " +
                firstNameTextBox.Text;

            //Display the output string in the label control.
            formattedNameTextBox.Text = output;
        }

      

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear text Boxes
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            preferredTitleTextBox.Text = "";
            formattedNameTextBox.Text = "";
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            // close application
            this.Close();
        }

        private void formattedNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void lastNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void preferredTitleTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
