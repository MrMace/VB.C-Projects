﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tip_Tax_and_Total
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double price; // hold Food price amount.
            double tip; //hold the tip amount
            double tax; // hold tax amount.
            double total; // holds the total amount.

            // get the price for food and assigns to the price variable.
            price = double.Parse(foodChargeAmountTextBox.Text);

            // calculate tip amount.
            tip = price * 0.15;

            // display tip amount control label
            tipTextBox.Text = tip.ToString("c");

            // calculate tax amount.
            tax = price * .07;

            // display tax amount in control label
            salesTaxTextBox.Text = tax.ToString("c");

            // calculate total.
            total = price + tip + tax;

            // display total amount
            totalTextBox.Text = total.ToString("c");


        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clear all textBoxes
            foodChargeAmountTextBox.Text = "";
            tipTextBox.Text = "";
            salesTaxTextBox.Text = "";
            totalTextBox.Text = "";

           
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes the application
            this.Close();

        }
    }
}
