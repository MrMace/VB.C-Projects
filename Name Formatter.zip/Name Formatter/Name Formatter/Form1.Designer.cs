﻿namespace Name_Formatter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.preferredTitleLabel = new System.Windows.Forms.Label();
            this.pleaseChooseLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.preferredTitleTextBox = new System.Windows.Forms.TextBox();
            this.titleFirstMiddleLastButton = new System.Windows.Forms.Button();
            this.firstMiddleLastNameButton = new System.Windows.Forms.Button();
            this.firstLastNameButton = new System.Windows.Forms.Button();
            this.lastFirstMiddleTitleNameButton = new System.Windows.Forms.Button();
            this.lastFirstMiddleNameButton = new System.Windows.Forms.Button();
            this.lastFirstNameButton = new System.Windows.Forms.Button();
            this.formattedNameTextBox = new System.Windows.Forms.TextBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(23, 53);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(80, 17);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(23, 83);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(94, 17);
            this.middleNameLabel.TabIndex = 1;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(23, 111);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(80, 17);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            this.lastNameLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // preferredTitleLabel
            // 
            this.preferredTitleLabel.AutoSize = true;
            this.preferredTitleLabel.Location = new System.Drawing.Point(23, 143);
            this.preferredTitleLabel.Name = "preferredTitleLabel";
            this.preferredTitleLabel.Size = new System.Drawing.Size(103, 17);
            this.preferredTitleLabel.TabIndex = 3;
            this.preferredTitleLabel.Text = "Preferred Title:";
            // 
            // pleaseChooseLabel
            // 
            this.pleaseChooseLabel.AutoSize = true;
            this.pleaseChooseLabel.Location = new System.Drawing.Point(64, 186);
            this.pleaseChooseLabel.Name = "pleaseChooseLabel";
            this.pleaseChooseLabel.Size = new System.Drawing.Size(379, 17);
            this.pleaseChooseLabel.TabIndex = 4;
            this.pleaseChooseLabel.Text = "Please choose a button with the format you are looking for.";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.firstNameTextBox.Location = new System.Drawing.Point(132, 53);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.firstNameTextBox.TabIndex = 5;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.middleNameTextBox.Location = new System.Drawing.Point(132, 83);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.middleNameTextBox.TabIndex = 6;
            this.middleNameTextBox.TextChanged += new System.EventHandler(this.middleNameTextBox_TextChanged);
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lastNameTextBox.Location = new System.Drawing.Point(132, 112);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.lastNameTextBox.TabIndex = 7;
            this.lastNameTextBox.TextChanged += new System.EventHandler(this.lastNameTextBox_TextChanged);
            // 
            // preferredTitleTextBox
            // 
            this.preferredTitleTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.preferredTitleTextBox.Location = new System.Drawing.Point(132, 140);
            this.preferredTitleTextBox.Name = "preferredTitleTextBox";
            this.preferredTitleTextBox.Size = new System.Drawing.Size(100, 22);
            this.preferredTitleTextBox.TabIndex = 8;
            this.preferredTitleTextBox.TextChanged += new System.EventHandler(this.preferredTitleTextBox_TextChanged);
            // 
            // titleFirstMiddleLastButton
            // 
            this.titleFirstMiddleLastButton.Location = new System.Drawing.Point(36, 220);
            this.titleFirstMiddleLastButton.Name = "titleFirstMiddleLastButton";
            this.titleFirstMiddleLastButton.Size = new System.Drawing.Size(426, 23);
            this.titleFirstMiddleLastButton.TabIndex = 9;
            this.titleFirstMiddleLastButton.Text = "Title, First Name, Middle Name, Last Name";
            this.titleFirstMiddleLastButton.UseVisualStyleBackColor = true;
            this.titleFirstMiddleLastButton.Click += new System.EventHandler(this.titleFirstMiddleLastButton_Click);
            // 
            // firstMiddleLastNameButton
            // 
            this.firstMiddleLastNameButton.Location = new System.Drawing.Point(36, 249);
            this.firstMiddleLastNameButton.Name = "firstMiddleLastNameButton";
            this.firstMiddleLastNameButton.Size = new System.Drawing.Size(426, 23);
            this.firstMiddleLastNameButton.TabIndex = 9;
            this.firstMiddleLastNameButton.Text = "First Name, Middle Name, Last Name";
            this.firstMiddleLastNameButton.UseVisualStyleBackColor = true;
            this.firstMiddleLastNameButton.Click += new System.EventHandler(this.firstMiddleLastNameButton_Click);
            // 
            // firstLastNameButton
            // 
            this.firstLastNameButton.Location = new System.Drawing.Point(36, 278);
            this.firstLastNameButton.Name = "firstLastNameButton";
            this.firstLastNameButton.Size = new System.Drawing.Size(426, 23);
            this.firstLastNameButton.TabIndex = 9;
            this.firstLastNameButton.Text = "First Name, Last Name";
            this.firstLastNameButton.UseVisualStyleBackColor = true;
            this.firstLastNameButton.Click += new System.EventHandler(this.firstLastNameButton_Click);
            // 
            // lastFirstMiddleTitleNameButton
            // 
            this.lastFirstMiddleTitleNameButton.Location = new System.Drawing.Point(36, 307);
            this.lastFirstMiddleTitleNameButton.Name = "lastFirstMiddleTitleNameButton";
            this.lastFirstMiddleTitleNameButton.Size = new System.Drawing.Size(426, 23);
            this.lastFirstMiddleTitleNameButton.TabIndex = 9;
            this.lastFirstMiddleTitleNameButton.Text = "Last Name, First Name, Middle Name, Title";
            this.lastFirstMiddleTitleNameButton.UseVisualStyleBackColor = true;
            this.lastFirstMiddleTitleNameButton.Click += new System.EventHandler(this.lastFirstMiddleTitleNameButton_Click);
            // 
            // lastFirstMiddleNameButton
            // 
            this.lastFirstMiddleNameButton.Location = new System.Drawing.Point(36, 336);
            this.lastFirstMiddleNameButton.Name = "lastFirstMiddleNameButton";
            this.lastFirstMiddleNameButton.Size = new System.Drawing.Size(426, 23);
            this.lastFirstMiddleNameButton.TabIndex = 9;
            this.lastFirstMiddleNameButton.Text = "Last Name, First Name, Middle Name";
            this.lastFirstMiddleNameButton.UseVisualStyleBackColor = true;
            this.lastFirstMiddleNameButton.Click += new System.EventHandler(this.lastFirstMiddleNameButton_Click);
            // 
            // lastFirstNameButton
            // 
            this.lastFirstNameButton.Location = new System.Drawing.Point(36, 365);
            this.lastFirstNameButton.Name = "lastFirstNameButton";
            this.lastFirstNameButton.Size = new System.Drawing.Size(426, 23);
            this.lastFirstNameButton.TabIndex = 9;
            this.lastFirstNameButton.Text = "Last Name, First Name";
            this.lastFirstNameButton.UseVisualStyleBackColor = true;
            this.lastFirstNameButton.Click += new System.EventHandler(this.lastFirstNameButton_Click);
            // 
            // formattedNameTextBox
            // 
            this.formattedNameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.formattedNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.formattedNameTextBox.Location = new System.Drawing.Point(36, 394);
            this.formattedNameTextBox.Name = "formattedNameTextBox";
            this.formattedNameTextBox.Size = new System.Drawing.Size(426, 27);
            this.formattedNameTextBox.TabIndex = 10;
            this.formattedNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.formattedNameTextBox.TextChanged += new System.EventHandler(this.formattedNameTextBox_TextChanged);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(67, 427);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(135, 23);
            this.clearButton.TabIndex = 11;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(288, 427);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(135, 23);
            this.closeButton.TabIndex = 12;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 483);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.formattedNameTextBox);
            this.Controls.Add(this.lastFirstNameButton);
            this.Controls.Add(this.lastFirstMiddleNameButton);
            this.Controls.Add(this.lastFirstMiddleTitleNameButton);
            this.Controls.Add(this.firstLastNameButton);
            this.Controls.Add(this.firstMiddleLastNameButton);
            this.Controls.Add(this.titleFirstMiddleLastButton);
            this.Controls.Add(this.preferredTitleTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.pleaseChooseLabel);
            this.Controls.Add(this.preferredTitleLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label preferredTitleLabel;
        private System.Windows.Forms.Label pleaseChooseLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox preferredTitleTextBox;
        private System.Windows.Forms.Button titleFirstMiddleLastButton;
        private System.Windows.Forms.Button firstMiddleLastNameButton;
        private System.Windows.Forms.Button firstLastNameButton;
        private System.Windows.Forms.Button lastFirstMiddleTitleNameButton;
        private System.Windows.Forms.Button lastFirstMiddleNameButton;
        private System.Windows.Forms.Button lastFirstNameButton;
        private System.Windows.Forms.TextBox formattedNameTextBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button closeButton;
    }
}

