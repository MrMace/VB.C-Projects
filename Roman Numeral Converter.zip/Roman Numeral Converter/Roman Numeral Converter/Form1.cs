﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            try
            {
                //hold the number
                int number;

                //Get the number.
                number = int.Parse(numberTextBox.Text);

                //Determine the Roman Numeral.
                if (number == 1)
                {
                    romanNumeralTextBox.Text = "I";
                }
                else if (number == 2)
                {
                    romanNumeralTextBox.Text = "II";
                }
                else if (number == 3)
                {
                    romanNumeralTextBox.Text = "III";
                }
                else if (number == 4)
                {
                    romanNumeralTextBox.Text = "IV";
                }
                else if (number == 5)
                {
                    romanNumeralTextBox.Text = "V";
                }
                else if (number == 6)
                {
                    romanNumeralTextBox.Text = "VI";
                }
                else if (number == 7)
                {
                    romanNumeralTextBox.Text = "VII";
                }
                else if (number == 8)
                {
                    romanNumeralTextBox.Text = "VIII";
                }
                else if (number == 9)
                {
                    romanNumeralTextBox.Text = "IX";
                }
                else if (number == 10)
                {
                    romanNumeralTextBox.Text = "X";
                }
                else
                {
                    MessageBox.Show("Please enter a number 1-10");
                }
            }
            catch (Exception ex)
            {
                //display error message.
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear textboxes
            numberTextBox.Text = " ";
            romanNumeralTextBox.Text = " ";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
