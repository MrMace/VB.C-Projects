﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //accepts argument and returns charges
        private double OilLubeCharges(double oil, double lube)
        {
            //return charges
            return oil + lube;
        }
        //accepts argument and returns charges
        private double FlushCharges(double radiator, double transmission)
        {
            //return charges
            return radiator + transmission;
        }
        //accepts argument and retrns charges.
        private double MiscCharges(double inspection, double muffler, double tire)
        {
            //return charges
            return inspection + muffler + tire;
        }
        //Gets argument and returns charges .
        private double OtherCharges(double parts, double labor)
        {
            //Return charges
            return parts + labor;
        }

        // Gets argument and returns tax charge
        private double TaxCharges(double parts, double labor,
        double oillube, double flush, double misc, double other)
        {
            if (parts != 0 && labor != 0 && oillube != 0
                && flush != 0 && misc != 0 && other != 0)
            {
                //Tax charges input
                return (parts * 0.06);
            }
            else
            {
                return 0;
            }
        }
        //accepts argument and returns totalCharges.
        private double TotalCharges(double oillube, double flush, double misc,
            double other, double tax)
        {
            return oillube + flush + misc + other + tax;
        }
        

        private void calculateButton_Click(object sender, EventArgs e)
        {
        try
            {

                //Declare variables set to zero value
                double oil = 0;
                double lube = 0;
                double radiator = 0;
                double transmission = 0;
                double inspection = 0;
                double muffler = 0;
                double tire = 0;

                //Checks to see if check boxes are checked
                if (oilCheckBox.Checked == true)
                {
                    oil = 26;
                }//Checks to see if check boxes are checked
                if (lubeCheckBox.Checked == true)
                {
                    lube = 18;
                }//Checks to see if check boxes are checked
                if (radiatorCheckBox.Checked == true)
                {
                    radiator = 30;
                }//Checks to see if check boxes are checked
                if (transCheckBox.Checked == true)
                {
                    transmission = 80;
                }//Checks to see if check boxes are checked
                if (inspectCheckBox.Checked == true)
                {
                    inspection = 15;
                }//Checks to see if check boxes are checked
                if (mufflerCheckBox.Checked == true)
                {
                    muffler = 100;
                }//Checks to see if check boxes are checked
                if (tireCheckBox.Checked == true)
                {
                    tire = 20;
                }

                //Gets the value and converts.
                double parts = double.Parse(partsTextBox.Text);
                double labor = double.Parse(laborTextBox.Text);
                //converts oil and lube to oilLube.
                double oillube = OilLubeCharges(oil, lube);
                //Conversts radiator and transmission to flush.
                double flush = FlushCharges(radiator, transmission);
                //converts inspection muffler, and tire into misc.
                double misc = MiscCharges(inspection, muffler, tire);
                //converts parts and labor into other.
                double other = OtherCharges(parts, labor);
                //converts parts, labor, oillube, flush , misc, and other for tax.
                double tax = TaxCharges(parts, labor, oillube, flush, misc, other);
                //converts totalCharges to total
                double total = TotalCharges(oillube, flush, misc, other, tax);
                //converts oillube, flush, misc, and labor to services.
                double services = oillube + flush + misc + labor;

                //Display
                serviceLaborTextBox.Text = services.ToString("c");
                partsTotalTextBox.Text = other.ToString("c");
                taxTextBox.Text = tax.ToString("c");
                totalTextBox.Text = total.ToString("c");
               
            
            }
            catch (Exception ex)
            {
                //Display error message.
                MessageBox.Show(ex.Message);
            }
        }
   

        private void clearButton_Click(object sender, EventArgs e)
        {
            //use methods to clear all.
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        //Uncheck oil and lube check boxes
        private void ClearOilLube()
        {
            if (oilCheckBox.Checked == true)
            {
                oilCheckBox.Checked = false;
            }
            if (lubeCheckBox.Checked == true)
            {
                lubeCheckBox.Checked = false;
            }
        }
        //Uncheck flushes check boxes
        private void ClearFlushes()
        {
            if (radiatorCheckBox.Checked == true)
            {
                radiatorCheckBox.Checked = false;
            }
            if (transCheckBox.Checked == true)
            {
                transCheckBox.Checked = false;
            }
        }
        //Unclech misc check boxes
        private void ClearMisc()
        {
            if (inspectCheckBox.Checked == true)
            {
                inspectCheckBox.Checked = false;
            }
            if (mufflerCheckBox.Checked == true)
            {
                mufflerCheckBox.Checked = false;
            }
            if (tireCheckBox.Checked == true)
            {
                tireCheckBox.Checked = false;
            }
        }
        //Clear input boxes
        private void ClearOther()
        {
            partsTextBox.Text = "";
            laborTextBox.Text = "";
        }
        //clear all text boxes
        private void ClearFees()
        {
           serviceLaborTextBox.Text = "";
            partsTotalTextBox.Text = "";
            taxTextBox.Text = "";
            totalTextBox.Text = "";
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }

    }
} 

