﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Random_Number_File_Writer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare a streamWriter variable
                StreamWriter outputFile;
                //declare number variable.
                int number = int.Parse(numberTextBox.Text); //Hold num variable.
                int count;//Hold loop counter
                int randomNumber; //Hold random num variable

                    if (saveFile.ShowDialog() == DialogResult.OK)
                    {
                        //create the selected file.
                        outputFile = File.CreateText(saveFile.FileName + ".txt");
                         //Create loop to write multiple random numbers to lines
                        for (count = 1; count <= number; count ++ )
                         {
                            //Create Random Object
                        Random rand = new Random(count);
                            //Get random number
                        randomNumber = rand.Next(100) + 1;
                            //Write to the file.
                        outputFile.WriteLine(randomNumber);
                        
                         }
                        //If save button pressed Message Displayed
                        MessageBox.Show("You clicked the save button.");
                        //close the file
                        outputFile.Close();

                        //close application
                        this.Close();
                    }
                    else
                    {
                        //if operation cancled
                        MessageBox.Show("you clicked the cancel button.");
                        //Close application.
                        this.Close();
                    }
                }
            catch (Exception ex)
            {
                //Displays error box
                MessageBox.Show(ex.Message);
            }
        }
        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
