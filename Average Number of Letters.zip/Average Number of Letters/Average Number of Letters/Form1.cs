﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Average_Number_of_Letters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        
        //accepts WordsCount method accepts a string argument
        //and returns the average number of letters within the
        //words it contains.
        private int WordsCount(string str)
        {
            int wordCount = 0; //number of words
            int letterCount =0; //number of letters
            int averageCount = 0; //holds average
           
            //Gets words from string 
            string[] strWords = str.Split(null);
            //Counts words within the string.
            wordCount = strWords.Length;
            //Counts letters.
            letterCount = str.Length;
            // averages out the average letters within the words.
            averageCount = letterCount / wordCount;
            //return average count
            return averageCount;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Add words to count to string.
            string str = phraseTextBox.Text;

            int averageNumWords = WordsCount(str);
            //Displays the average number of letters for each word.
            MessageBox.Show("The average number of letters within the words are " +
                averageNumWords.ToString());
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
