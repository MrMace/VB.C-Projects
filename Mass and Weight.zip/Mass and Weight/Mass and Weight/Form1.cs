﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mass_and_Weight
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                const decimal WEIGHT_HEAVY = 1000m; //to heavy.
                const decimal WEIGHT_LIGHT = 10m;  //too light
                double weight;
                double mass;
                decimal newtons;//variables

                     //Get the Mass from textBox.
                 mass = double.Parse(massTextBox.Text);

                // Calculate the weight.
                 weight = (double)mass * 9.8 ;

                 newtons = (decimal)weight;

                // display the weight
                 weightTextBox.Text = weight.ToString("f");

                // If newtons are to heavy, Messagebox tells user.
                if (newtons > WEIGHT_HEAVY)
                {
                    MessageBox.Show("Item is to Heavy");
                }

                // If newtons are to light, Message box tells user.
                if (newtons < WEIGHT_LIGHT)
                {
                    MessageBox.Show("Item is to Light");
                }

            }
            catch (Exception ex)
            {
                // Display the default Message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear textbox
            weightTextBox.Text = " ";
            massTextBox.Text = " ";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close application
            this.Close();
        }
    }
}
