﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Club_Points
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double books = 0;
                //get num books
                books = double.Parse(booksTextBox.Text);

                if (books == 0)
                {
                    pointsTextBox.Text = "0";
                }

                else if (books == 1)
                {
                    pointsTextBox.Text = "5";
                }
                else if (books == 2)
                {
                    pointsTextBox.Text = "15";
                }
                else if (books == 3)
                {
                    pointsTextBox.Text = "30";
                }
                else if (books >= 4)
                {
                    pointsTextBox.Text = "60";
                }

                else
                {
                    MessageBox.Show("Please enter a number");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear TextBox
            booksTextBox.Text = " ";
            pointsTextBox.Text = " ";
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close app
            this.Close();
        }
    }
}
