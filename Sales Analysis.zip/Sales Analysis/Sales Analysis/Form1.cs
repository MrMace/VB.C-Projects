﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sales_Analysis
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Average method accepts an int array argument and returns the
        // average of the vaalues array.
        private decimal Average (decimal[] iArray)
        {
            decimal total = 0;  //Accumulator, initialized to 0
            decimal average; //HHold average

            //Step through the array, adding each element to accumulator.
            for (int index = 0; index < iArray.Length; index++)
            {
                total += iArray[index];
            }
            //calculate the average.
            average = (decimal)total / iArray.Length;

            //Return average
            return average;
        }

        //Highest method acepts int array argument and returns the 
        // highest value array.
        private decimal Highest(decimal[] iArray)
        {
            //Declare a varuable to old highest value, and initialize
            //it with the first value.
            decimal highest = iArray[0];

            //Step through the rest of the array, beginning at element 1.
            //when a value is greater than highest is found. assign that value to highest.
            for (int index = 1; index < iArray.Length; index++)
            {
                if (iArray[index] > highest)
                {
                    highest = iArray[index];
                }
            }
            //Return the highest value.
            return highest;
        }

        //Lowest method accepts int array argument and returns the lowest value
        //array.
        private decimal Lowest(decimal[] iArray)
        {
            //Declare a variable to hold the lowest value, and initialize
            //it with the first value in the array.
            decimal lowest = iArray[0];

            //Step through the rest of the array, beginning at element 1.
            //when a value is at its lowest, assign that value to lowest.
            for (int index = 1; index < iArray.Length; index++)
            {
                if (iArray[index] < lowest)
                {
                    lowest = iArray[index];
                }
            }
            //return the lowest value
                return lowest;
        }
        private decimal Total(decimal[] iArray)
        {
            //Declare a variable to hold the total value, and initialize
            //it with the total.
            decimal total = iArray[0];
            //Step through the rest of the array, and get the total of sales.
            for(int index =1; index < iArray.Length; index++)
            {
                total += iArray[index];
            }
            return total;
        }
        private void calculateButton_Click(object sender, EventArgs e)
        {
             try
            {
                 //local variables.
                
                 decimal[] numbers = new decimal[7]; //Array of the sales.
                 int index = 0; //Loop counter.
                 decimal highestSales; //hold highest sale.
                 decimal lowestSales;  //hold lowest sale.
                 decimal averageSales; //hold average sale.
                 decimal totalSales;// hold total sale
                 StreamReader inputFile;

                //Read file.
                inputFile = File.OpenText("Sales.txt"); 
                 //Read sales into array

                 while (!inputFile.EndOfStream && index < numbers.Length)
                {
                    numbers[index] = decimal.Parse(inputFile.ReadLine());
                    //add to count
                    index++;
                }
                 

                //Close the file.
                inputFile.Close();

                foreach (decimal value in numbers)
                {
                    //Add to listBox.
                    salesListBox.Items.Add(value);
                }
                    
                    //get the highest, lowest, and average scores.
                    highestSales = Highest(numbers);
                    lowestSales = Lowest(numbers);
                    averageSales = Average(numbers);
                    totalSales = Total(numbers);

                 //Display values
                    highestTextBox.Text = highestSales.ToString("c");
                    lowestTextBox.Text = lowestSales.ToString("c");
                    averageTextBox.Text = averageSales.ToString("c");
                    totalTextBox.Text = totalSales.ToString("c");
                    numSalesTextBox.Text = index.ToString();
            }
            catch (Exception ex)
            {
                //Display error message.
                MessageBox.Show(ex.Message);
            }
        }
        
        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
