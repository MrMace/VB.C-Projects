﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Morse_Code_Converter
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            
            InitializeComponent();
        }
        public string MorseCodeConverter(char input)
        {
            string convertCode = string.Empty;

           Dictionary <char,string> morseConverter = new Dictionary <char,string>()
            {
           
{' ' , "space"}, {',' , "--..--"}, {'.' , ".-.-.-"},
{'?' , "..--.."}, {'0' , "-----"}, {'1' , ".----"},
{'2' , "..---"}, {'3' , "...--"}, {'4' , "....-"},
{'5' , "....."}, {'6' , "-...."}, {'7' , "--..."},
{'8' , "---.."}, {'9' , "----."}, {'A' , ".-"},
{'B' , "-..."}, {'C' , "-.-."}, {'D' , "-.."},
{'E' , "."}, {'F' , "..-."}, {'G' , "--."},
{'H' , "...."}, {'I' , ".."}, {'J' , ".---"},
{'K' , "-.-"}, {'L' , ".-.."}, {'M' , "--"},
{'N' , "-."}, {'O' , "---"}, {'P' , ".--."},
{'Q' , "--.-"}, {'R' , ".-."}, {'S' , "..."},
{'T', "-"}, {'U' , "..-"}, {'V', "...-"}, {'W', ".--"},
{'X' , "-..-"}, {'Y', "-.--"}, {'Z' , "--.."}
        };
           

            char uChar;

            foreach (char ch in input)
            {
                char.ToUpper(ch);
                uChar = char.ToUpper(ch);
                if(morseConverter.ContainsKey(uChar))
                {
                    convertCode += morseConverter[uChar];
                }
                else
                {
                    convertCode += ch;
                }
                return convertCode;
            }
        }
        private void convertButton_Click(object sender, EventArgs e)
        {
            //
            string input = phraseTextBox.Text.Trim();

            morseCodeTextBox.Text = MorseCodeConverter(input);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
        //Close applicaiton
            this.Close();
        }
    }
}
