﻿namespace Tip_Tax_and_Total
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.foodChargeLabel = new System.Windows.Forms.Label();
            this.foodChargeAmountTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.tipLabel = new System.Windows.Forms.Label();
            this.tipTextBox = new System.Windows.Forms.TextBox();
            this.salesTaxLabel = new System.Windows.Forms.Label();
            this.salesTaxTextBox = new System.Windows.Forms.TextBox();
            this.totalLabel = new System.Windows.Forms.Label();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // foodChargeLabel
            // 
            this.foodChargeLabel.AutoSize = true;
            this.foodChargeLabel.Location = new System.Drawing.Point(12, 34);
            this.foodChargeLabel.Name = "foodChargeLabel";
            this.foodChargeLabel.Size = new System.Drawing.Size(88, 17);
            this.foodChargeLabel.TabIndex = 0;
            this.foodChargeLabel.Text = "Price of food";
            // 
            // foodChargeAmountTextBox
            // 
            this.foodChargeAmountTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.foodChargeAmountTextBox.Location = new System.Drawing.Point(106, 29);
            this.foodChargeAmountTextBox.Name = "foodChargeAmountTextBox";
            this.foodChargeAmountTextBox.Size = new System.Drawing.Size(100, 22);
            this.foodChargeAmountTextBox.TabIndex = 1;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(34, 178);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(79, 31);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // tipLabel
            // 
            this.tipLabel.AutoSize = true;
            this.tipLabel.Location = new System.Drawing.Point(103, 73);
            this.tipLabel.Name = "tipLabel";
            this.tipLabel.Size = new System.Drawing.Size(112, 17);
            this.tipLabel.TabIndex = 3;
            this.tipLabel.Text = "15% Tip Amount";
            // 
            // tipTextBox
            // 
            this.tipTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipTextBox.Location = new System.Drawing.Point(262, 68);
            this.tipTextBox.Name = "tipTextBox";
            this.tipTextBox.Size = new System.Drawing.Size(100, 22);
            this.tipTextBox.TabIndex = 4;
            this.tipTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // salesTaxLabel
            // 
            this.salesTaxLabel.AutoSize = true;
            this.salesTaxLabel.Location = new System.Drawing.Point(103, 102);
            this.salesTaxLabel.Name = "salesTaxLabel";
            this.salesTaxLabel.Size = new System.Drawing.Size(146, 17);
            this.salesTaxLabel.TabIndex = 5;
            this.salesTaxLabel.Text = "7% Sales Tax Amount";
            // 
            // salesTaxTextBox
            // 
            this.salesTaxTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesTaxTextBox.Location = new System.Drawing.Point(262, 97);
            this.salesTaxTextBox.Name = "salesTaxTextBox";
            this.salesTaxTextBox.Size = new System.Drawing.Size(100, 22);
            this.salesTaxTextBox.TabIndex = 6;
            this.salesTaxTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(161, 145);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(88, 17);
            this.totalLabel.TabIndex = 7;
            this.totalLabel.Text = "Grand Total:";
            // 
            // totalTextBox
            // 
            this.totalTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalTextBox.Location = new System.Drawing.Point(262, 139);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(100, 22);
            this.totalTextBox.TabIndex = 8;
            this.totalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(273, 179);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(79, 30);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(152, 179);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(79, 30);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 226);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.totalTextBox);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.salesTaxTextBox);
            this.Controls.Add(this.salesTaxLabel);
            this.Controls.Add(this.tipTextBox);
            this.Controls.Add(this.tipLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.foodChargeAmountTextBox);
            this.Controls.Add(this.foodChargeLabel);
            this.Name = "Form1";
            this.Text = "Tip Tax  and Total";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label foodChargeLabel;
        private System.Windows.Forms.TextBox foodChargeAmountTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label tipLabel;
        private System.Windows.Forms.TextBox tipTextBox;
        private System.Windows.Forms.Label salesTaxLabel;
        private System.Windows.Forms.TextBox salesTaxTextBox;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

