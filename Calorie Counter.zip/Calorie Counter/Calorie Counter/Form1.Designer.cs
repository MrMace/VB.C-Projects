﻿namespace Calorie_Counter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.totalCaloriesLabel = new System.Windows.Forms.Label();
            this.calorieCountTextBox = new System.Windows.Forms.TextBox();
            this.oneFifteenCalPictureBox = new System.Windows.Forms.PictureBox();
            this.eightyCalPictureBox = new System.Windows.Forms.PictureBox();
            this.nintyCalPictureBox = new System.Windows.Forms.PictureBox();
            this.oneTwentyCalPictureBox = new System.Windows.Forms.PictureBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.oneFifteenCalPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightyCalPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nintyCalPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oneTwentyCalPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // totalCaloriesLabel
            // 
            this.totalCaloriesLabel.AutoSize = true;
            this.totalCaloriesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCaloriesLabel.Location = new System.Drawing.Point(315, 32);
            this.totalCaloriesLabel.Name = "totalCaloriesLabel";
            this.totalCaloriesLabel.Size = new System.Drawing.Size(114, 17);
            this.totalCaloriesLabel.TabIndex = 0;
            this.totalCaloriesLabel.Text = "Total Calories:";
            // 
            // calorieCountTextBox
            // 
            this.calorieCountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calorieCountTextBox.Location = new System.Drawing.Point(318, 53);
            this.calorieCountTextBox.Name = "calorieCountTextBox";
            this.calorieCountTextBox.Size = new System.Drawing.Size(100, 22);
            this.calorieCountTextBox.TabIndex = 1;
            this.calorieCountTextBox.Text = "0";
            this.calorieCountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // oneFifteenCalPictureBox
            // 
            this.oneFifteenCalPictureBox.Image = global::Calorie_Counter.Properties.Resources.BananaCalories;
            this.oneFifteenCalPictureBox.Location = new System.Drawing.Point(12, 12);
            this.oneFifteenCalPictureBox.Name = "oneFifteenCalPictureBox";
            this.oneFifteenCalPictureBox.Size = new System.Drawing.Size(128, 155);
            this.oneFifteenCalPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.oneFifteenCalPictureBox.TabIndex = 2;
            this.oneFifteenCalPictureBox.TabStop = false;
            this.oneFifteenCalPictureBox.Click += new System.EventHandler(this.oneFifteenCalPictureBox_Click);
            // 
            // eightyCalPictureBox
            // 
            this.eightyCalPictureBox.Image = global::Calorie_Counter.Properties.Resources.AppleCalories;
            this.eightyCalPictureBox.Location = new System.Drawing.Point(146, 12);
            this.eightyCalPictureBox.Name = "eightyCalPictureBox";
            this.eightyCalPictureBox.Size = new System.Drawing.Size(128, 155);
            this.eightyCalPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.eightyCalPictureBox.TabIndex = 3;
            this.eightyCalPictureBox.TabStop = false;
            this.eightyCalPictureBox.Click += new System.EventHandler(this.eightyCalPictureBox_Click);
            // 
            // nintyCalPictureBox
            // 
            this.nintyCalPictureBox.Image = global::Calorie_Counter.Properties.Resources.OrangeCalories;
            this.nintyCalPictureBox.Location = new System.Drawing.Point(12, 173);
            this.nintyCalPictureBox.Name = "nintyCalPictureBox";
            this.nintyCalPictureBox.Size = new System.Drawing.Size(128, 155);
            this.nintyCalPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.nintyCalPictureBox.TabIndex = 4;
            this.nintyCalPictureBox.TabStop = false;
            this.nintyCalPictureBox.Click += new System.EventHandler(this.nintyCalPictureBox_Click);
            // 
            // oneTwentyCalPictureBox
            // 
            this.oneTwentyCalPictureBox.Image = global::Calorie_Counter.Properties.Resources.PearCalories;
            this.oneTwentyCalPictureBox.Location = new System.Drawing.Point(146, 173);
            this.oneTwentyCalPictureBox.Name = "oneTwentyCalPictureBox";
            this.oneTwentyCalPictureBox.Size = new System.Drawing.Size(128, 155);
            this.oneTwentyCalPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.oneTwentyCalPictureBox.TabIndex = 5;
            this.oneTwentyCalPictureBox.TabStop = false;
            this.oneTwentyCalPictureBox.Click += new System.EventHandler(this.oneTwentyCalPictureBox_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(318, 276);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(100, 23);
            this.resetButton.TabIndex = 6;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(318, 305);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(100, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 378);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.oneTwentyCalPictureBox);
            this.Controls.Add(this.nintyCalPictureBox);
            this.Controls.Add(this.eightyCalPictureBox);
            this.Controls.Add(this.oneFifteenCalPictureBox);
            this.Controls.Add(this.calorieCountTextBox);
            this.Controls.Add(this.totalCaloriesLabel);
            this.Name = "Form1";
            this.Text = "Calorie Counter";
            ((System.ComponentModel.ISupportInitialize)(this.oneFifteenCalPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightyCalPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nintyCalPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oneTwentyCalPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label totalCaloriesLabel;
        private System.Windows.Forms.TextBox calorieCountTextBox;
        private System.Windows.Forms.PictureBox oneFifteenCalPictureBox;
        private System.Windows.Forms.PictureBox eightyCalPictureBox;
        private System.Windows.Forms.PictureBox nintyCalPictureBox;
        private System.Windows.Forms.PictureBox oneTwentyCalPictureBox;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

