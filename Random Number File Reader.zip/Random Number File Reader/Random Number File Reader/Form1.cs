﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Random_Number_File_Reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            try
            {
                double number;
                double numSum = 0;
                double count = 1;
                

                StreamReader inputFile;

                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    //Open the selected file.
                    inputFile = File.OpenText(openFile.FileName);
                    //Read the file's contents.
                    while(!inputFile.EndOfStream)
                        {
                            //Get list of numbers
                            number = double.Parse(inputFile.ReadLine());
                            //display list of random numbers
                            listBox.Items.Add(number);
                            //Add to total.
                            numSum += number;
                        }
                    // Count text lines.
                    count = listBox.Items.Count;
                    //Display final count.
                    totalRanNumTextBox.Text = count.ToString();
                        //Close the file
                        inputFile.Close();
                    //Display the sum of all the numbers together.
                    numberSumTextBox.Text = numSum.ToString();
                    }     
            }
            catch (Exception ex)
            {
                //Display error message.
                MessageBox.Show(ex.Message);
            }  
        }
        private void closeButton_Click(object sender, EventArgs e)
        {
            //close application
            this.Close();
        }  
    }
}
