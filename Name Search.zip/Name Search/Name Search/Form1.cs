﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Name_Search
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        //BoyList reads and returns the the file.
        private void BoyList(List<string> boyNameList)
        {
            //opens BoyNmes file.
            StreamReader inputFile = File.OpenText("BoyNames.txt");
            //Read Names into list.
            while (!inputFile.EndOfStream)
            {
                boyNameList.Add(inputFile.ReadLine());
            }
            //Close File
            inputFile.Close();
        }
        //GirlList reads and returns the file.
        private void GirlList(List<string> girlNameList)
        {
            //Opens GirlNames file.
            StreamReader inputFile = File.OpenText("GirlNames.txt");
            //Reads names into list
            while (!inputFile.EndOfStream)
            {
                girlNameList.Add(inputFile.ReadLine());
            }
            //Close File
            inputFile.Close();

        }
        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {

                //Create list to hold names.
                List<String> boyNameList = new List<String>();
                List<String> girlNameList = new List<String>();
                String name;
                bool nameFound = false;

                name = nameTextBox.Text;
                //Reads the names from boys File
                BoyList(boyNameList);
                //REads names form girls file.
                GirlList(girlNameList);


             

                 //check to see if names match from boy file.
                    foreach (String names in boyNameList)
                    {
                        if(names == name)
                        {
                            //names match nameFound becomes True.
                            nameFound = true;
                        }
                    }
                      //check see if names match from girl file.
                        foreach (String gnames in girlNameList)
                        {
                            if(gnames == name)
                            {
                                //names match nameFound becomes True.
                                nameFound = true;
                            }
                        }

                
                    if (nameFound)
                    {
                        //Display if account is valid.
                        MessageBox.Show("The name " + name + " was a popular name.");
                    }
                    else
                    {
                        //Display if accont is not valid
                        MessageBox.Show("The name " + name + " was not a popular name.");
                    }

                }
            
            catch (Exception ex)
            {
                //Display error message.
                MessageBox.Show(ex.Message);
            }

    }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
        }
    }

