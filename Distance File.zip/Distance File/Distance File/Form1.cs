﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Distance_File
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare a StreamWriter Variable.
                StreamWriter outputFile;

                double speed; //The vehicle speed.
                double hours; // Amount of hours driven.
                double distance = 0; //For distance variable
                int count = 1; //Loop counter, initilized with 1.

                // Create a file and get StreamWriter object.
                outputFile = File.CreateText("Distance Converted.txt");

                //Get speed and hours
                speed = double.Parse(speedTextBox.Text);
                hours = double.Parse(hoursTextBox.Text);
                
                //Loop calculate the distance
                while (count <= hours)
                {
                    //calculation for distnace
                    distance = speed * count;

                    //Display in file.
                    outputFile.WriteLine("After hour " + count +
                        " the distance is " + distance.ToString(""));

                    //Add one to the loop counter.
                    count = count + 1;

                }
                //Close the file.
                outputFile.Close();
            }
            catch (Exception ex)
            {
                //Display error message
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //CLose application
            this.Close();
        }
    }
}
