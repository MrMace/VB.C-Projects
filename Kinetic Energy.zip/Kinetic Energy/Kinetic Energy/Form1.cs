﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kinetic_Energy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //the KineticEnergy argument is called and returned.
        private double KineticEnergy(double mass, double velocity)
        {
            //Compute and return
            return 0.5 * mass * Math.Pow(velocity, 2);
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //variables.
                double mass;
                double velocity;
                double energy;

                //string to double.
                mass = double.Parse(massTextBox.Text);
                velocity = double.Parse(velocityTextBox.Text);

                //Call method
                energy = KineticEnergy(mass, velocity);

                //Display Answer.
                MessageBox.Show("The objects Kinetic engery is: " +
                    energy);
            }

            catch (Exception ex)
            {
                //display error message
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }

    }
}
