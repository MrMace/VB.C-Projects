﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drink_Vedning_Machine_Simulator
{
    struct Drinks
    {
        //Structure declarations.
        public string name;
        public decimal cost;
        public int inventory;
    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int SIZE = 5; //const hold SIZE
        Drinks[] drinks = new Drinks[SIZE]; //array
        decimal total = 0.0m; //hold total
        //soda inventory variables.
        int colaInv = 20; 
        int lemonLimeInv = 20;
        int creamSodaInv = 20;
        int rootBeerInv = 20;
        int grapeSodaInv = 20;
        
       
        private void colaPictureBox_Click(object sender, EventArgs e)
        {
            Drinks cola = new Drinks();
            //Assign Value to object fields.
            cola.name = "cola";
            cola.cost = 1.00m;
            cola.inventory = 20;
            drinks[0] = cola;
            //display inventory.
            colaTextBox.Text = colaInv.ToString();
            
            if (colaInv == 0)
            {
                //grants the of the inventory.
                total = cola.cost + total;
                //Displays out of stock message.
                MessageBox.Show("Cola is now out of stock.");
                //Turns inventory display to 0.
                colaTextBox.Text = "0";
                //Disables the clicking of the picturebox.
                colaPictureBox.Enabled = false;
            }
                //Fix off by one
            else if (colaInv == 20)
            {
                //subtracts one from inventory
                colaInv--;
            }
            else
            {
                //subtracts one from inventory and adds to total.
                colaInv = colaInv - 1;
                //Adds cost to total.
                total = cola.cost + total;
            }
            //for total.
            drinkCalculation(drinks); 

        }

        private void rootBeerPictureBox_Click(object sender, EventArgs e)
        {
            Drinks rootBeer = new Drinks();
            //Assign Value to object fields.
            rootBeer.name = "root beer";
            rootBeer.cost = 1.00m;
            rootBeer.inventory = 20;
            drinks[3] = rootBeer;


            //display inventory.
            rootBeerTextBox.Text = rootBeerInv.ToString();

            if (rootBeerInv == 0)
            {
                //Displays out of stock message.
                MessageBox.Show("Root Beer is now out of stock.");
                //Turns inventory display to 0.
                rootBeerTextBox.Text = "0";
                //grants the of the inventory.
                total = rootBeer.cost + total;
                //Disables the clicking of the picturebox.
                rootBeerPictureBox.Enabled = false;
            }
            //Fix off by one
            else if (rootBeerInv == 20)
            {
                //subtracts one from inventory
                rootBeerInv--;
            }
            else
            {
                //subtracts one from inventory and adds to total.
                rootBeerInv = rootBeerInv - 1;
                //Adds cost to total.
                total = rootBeer.cost + total;
            }
            //for total.
            drinkCalculation(drinks); 

        }

        private void lemonLimePictureBox_Click(object sender, EventArgs e)
        {
            Drinks lemonLime = new Drinks();
            //Assign Value to object fields.
            lemonLime.name = "lemon lime";
            lemonLime.cost = 1.00m;
            lemonLime.inventory = 20;

            drinks[1] = lemonLime;
            //display inventory.
            lemonLimeTextBox.Text = lemonLimeInv.ToString();

            if (lemonLimeInv == 0)
            {
                //Displays out of stock message.
                MessageBox.Show("Lemon Lime is now out of stock.");
                //Turns inventory display to 0.
                lemonLimeTextBox.Text = "0";
                //grants the of the inventory.
                total = lemonLime.cost + total;
                //Disables the clicking of the picturebox.
                lemonLimePictureBox.Enabled = false;
            }
            //Fix off by one
            else if (lemonLimeInv == 20)
            {
                //subtracts one from inventory
                lemonLimeInv--;
            }
            else
            {
                //subtracts one from inventory and adds to total.
                lemonLimeInv = lemonLimeInv - 1;
                //Adds cost to total.
                total = lemonLime.cost + total;
            }
            //for total.
            drinkCalculation(drinks); 
        }

        private void grapeSodaPictureBox_Click(object sender, EventArgs e)
        {
            Drinks grapeSoda = new Drinks();
            //Assign Value to object fields.
            grapeSoda.name = "grape soda";
            grapeSoda.cost = 1.50m;
            grapeSoda.inventory = 20;

            drinks[4] = grapeSoda;
            //display inventory.
            grapeSodaTextBox.Text = grapeSodaInv.ToString();

            if (grapeSodaInv == 0)
            {
                //Displays out of stock message.
                MessageBox.Show("Grape Soda is now out of stock.");
                //Turns inventory display to 0.
                grapeSodaTextBox.Text = "0";
                //grants the of the inventory.
                total = grapeSoda.cost + total;
                //Disables the clicking of the picturebox.
                grapeSodaPictureBox.Enabled = false;
            }
            //Fix off by one
            else if (grapeSodaInv == 20)
            {
                //subtracts one from inventory
                grapeSodaInv--;
            }
            else
            {
                //subtracts one from inventory and adds to total.
                grapeSodaInv = grapeSodaInv - 1;
                //Adds cost to total.
                total = grapeSoda.cost + total;
            }
            //for total.
            drinkCalculation(drinks); 
        }

        private void creamSodaPictureBox_Click(object sender, EventArgs e)
        {
            Drinks creamSoda = new Drinks();
            //Assign Value to object fields.
            creamSoda.name = "cream soda";
            creamSoda.cost = 1.50m;
            creamSoda.inventory = 20;

            
            drinks[2] = creamSoda;
            //display inventory.
            creamSodaTextBox.Text = creamSodaInv.ToString();

            if (creamSodaInv == 0)
            {
                //Displays out of stock message.
                MessageBox.Show("Cream Soda is now out of stock.");
                //Turns inventory display to 0.
                creamSodaTextBox.Text = "0";
                //grants the of the inventory.
                total = creamSoda.cost + total;
                //Disables the clicking of the picturebox.
                creamSodaPictureBox.Enabled = false;
            }
            //Fix off by one
            else if (creamSodaInv == 20)
            {
                //subtracts one from inventory
                creamSodaInv--;
            }
            else
            {
                //subtracts one from inventory and adds to total.
                creamSodaInv = creamSodaInv - 1;
                //Adds cost to total.
                total = creamSoda.cost + total;
            }
            //for total.
            drinkCalculation(drinks); 
        }
       
        void drinkCalculation(Drinks[] x)
        {
            foreach (Drinks drinkType in drinks)
            {
                //Display the total.
                totalTextBox.Text = total.ToString("c");
            }

        }
      
        private void Form1_Load(object sender, EventArgs e)
        {
            //Display the stock at start up.
            colaTextBox.Text = colaInv.ToString();
            rootBeerTextBox.Text = rootBeerInv.ToString();
            grapeSodaTextBox.Text = grapeSodaInv.ToString();
            lemonLimeTextBox.Text = lemonLimeInv.ToString();
            creamSodaTextBox.Text = creamSodaInv.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close applicaiton
            this.Close();
        }

    }
}
