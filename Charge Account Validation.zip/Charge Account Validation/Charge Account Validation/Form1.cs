﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Charge_Account_Validation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {

            try
            {
              
            //Create list to hold account information.
            List<int> accountList = new List<int>();
            int accountNum = 0;

               //Set the account number to accountNum Var
            accountNum = int.Parse(accountNumTextBox.Text);

                //Open File
                StreamReader inputFile = File.OpenText("ChargeAccounts.txt");

                while (!inputFile.EndOfStream)
                {
                    accountList.Add(int.Parse(inputFile.ReadLine()));
                }
                //Close File
                inputFile.Close();

                //Flag variable indicate if account is good.
                //starting false until numbers are reconized.
                bool accountFound = false;
                    
                    //check to see if account numbers match/validate.
                    foreach (int account in accountList)
                    {

                        if(account == accountNum)
                        {
                            //numbers match accountFound becomes True.
                            accountFound = true;
                        }
                    }

                if (accountFound)
                {
                    //Display if account is valid.
                    MessageBox.Show("The account is valid.");
                }
                else
                {
                    //Display if accont is not valid
                    MessageBox.Show("The account is not valid.");
                }
         }
        catch (Exception ex)
            {
                //Display error message.
                MessageBox.Show(ex.Message);
            }

    }
 

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close Application
            this.Close();
        }
    }
}
