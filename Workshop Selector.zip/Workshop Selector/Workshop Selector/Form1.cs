﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Selector
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            string workshop; // hold which workshop.
            string location; // hold location.
            decimal registration = 0.0m; //var
            decimal days = 0;//var
            decimal lodge = 0.0m;//var
            decimal lodgetotal = 0.0m;//var
            decimal total = 0.0m;//Var
            //select workshop
            if (workshopListBox.SelectedIndex != -1)
            {
                //get selected item.
                workshop = workshopListBox.SelectedItem.ToString();
               
                switch (workshop)
                {
                    case "Handling Stress":
                        registration = 1000;
                        days = 3;
                        break;
                    case "Time Management":
                        registration = 800;
                        days = 3;
                        break;
                    case "Supervision Skills":
                        registration = 1500;
                        days = 3;
                        break;
                    case "Negotiation":
                        registration = 1300;
                        days = 5;
                        break;
                    case "How to Interview":
                        registration = 500;
                        days = 1;
                        break;
                }
            }
            else
            {
                // if no workshop is selected.
                MessageBox.Show("Please select a Workshop.");
            }
                // select location
                if (locationListBox.SelectedIndex != -1)
                {
                    //Get selected Item.
                    location = locationListBox.SelectedItem.ToString();
                        switch (location)
                        {
                            case "Austin":
                                lodge = 150;
                                break;
                            case "Chicago":
                                lodge = 225;
                                break;
                            case "Dallas":
                                lodge = 175;
                                break;
                            case "Orlando":
                                lodge = 300;
                                break;
                            case "Phoenix":
                                lodge = 175;
                                break;
                            case "Raleigh":
                                lodge = 150;
                                break;
                        }
                    }
                else
                {
                    // if no location is selected.
                    MessageBox.Show("Please select a Location.");
                }
                    //calculate fees.
                lodgetotal = lodge * days;
                total = registration + lodgetotal;
                //Display
                registrationCostTextBox.Text = registration.ToString("c");
                lodgingCostTextBox.Text = lodgetotal.ToString("c");
                totalTextBox.Text = total.ToString("c");
            }
        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear boxes
            registrationCostTextBox.Text = " ";
            lodgingCostTextBox.Text = " ";
            totalTextBox.Text = " ";
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close Application
            this.Close();
        }
    }
}
