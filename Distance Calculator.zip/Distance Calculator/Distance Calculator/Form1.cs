﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Distance_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
           
            double speed; //The vehicle speed.
            double hours; //Amount of hours driven.
            double distance = 0;
            int count = 1; // Loop counter, initilized with 1.

            

            //Get the speed.
            if (double.TryParse(speedTextBox.Text, out speed))
            {
                //Get the number of hours.
                if (double.TryParse(hoursTextBox.Text, out hours))
                {
                    //Loop calculates the distance
                    while (count <= hours)
                    {
                        //Add this to get distance
                        distance = speed * count;

                        //Display the distance 
                        outputFile.WriteLine("After hour " + count +
                            " the distance is " + distance.ToString(""));

                        //Add one to the loop counter
                        count = count + 1;
                    }
                 

                    else 
                    {
                    //Invalid number was entered for hours
                    MessageBox.Show("Invalid value for Hours.");
                    }
                }
            else
            {
                //Invalid value for speed.
                MessageBox.Show("Invalid value for vehicle Speed.");
            }
            }
      

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close application
            this.Close();
        }
    }
}
